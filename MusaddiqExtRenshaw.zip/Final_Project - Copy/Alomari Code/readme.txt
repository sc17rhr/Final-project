run the commands in following order

python Robot_simulation.py

python tf_idf.py

python linguistic_features.py

python visual_features.py

python tags.py

python grammar_generation.py

#python semantic_grammar_generation.py

python language_and_vision.py
